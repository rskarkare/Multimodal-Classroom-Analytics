"""
Full independent verification of all 6 models.
Checks:
  1. Every participant response row against raw CSV
  2. Every computed metric (score, f1, correct, ordinal_distance) recomputed independently
  3. Every IRR summary value recomputed independently
"""

import pandas as pd
import numpy as np
from collections import defaultdict

raw = pd.read_csv('/mnt/user-data/uploads/VideoAnonymization_PilotStudy_April_22__2026_18_15.csv', header=None)
cols = list(raw.iloc[0])
qtxt = list(raw.iloc[1])
data = raw.iloc[3:].copy()
data.columns = cols
EXCLUDED  = {"R_2PbOzedGEfSO1DR", "R_7q9H9RfaOnyjram"}
data = data[~data['ResponseId'].isin(EXCLUDED)].reset_index(drop=True)

gt_act = pd.read_excel('/home/claude/scoring_pipeline/Scoring_Pipeline/ground_truth_labels.xlsx', sheet_name='Activity',   header=1)
gt_eng = pd.read_excel('/home/claude/scoring_pipeline/Scoring_Pipeline/ground_truth_labels.xlsx', sheet_name='Engagement', header=1)
gt_gaz = pd.read_excel('/home/claude/scoring_pipeline/Scoring_Pipeline/ground_truth_labels.xlsx', sheet_name='Gaze',       header=1)

# ── Helpers ────────────────────────────────────────────────────────────────

def norm(text):
    if not isinstance(text, str): return ''
    return text.strip().rstrip('?').strip().lower()

def norm_set(text):
    if not isinstance(text, str) or not text.strip(): return frozenset()
    return frozenset(norm(s) for s in text.split(',') if s.strip())

def recompute_multiselect(resp_str, gt_set):
    resp_set  = norm_set(str(resp_str)) if pd.notna(resp_str) else frozenset()
    inter     = resp_set & gt_set
    union     = resp_set | gt_set
    prec      = round(len(inter)/len(resp_set),4) if resp_set else 0.0
    rec       = round(len(inter)/len(gt_set),  4) if gt_set   else 1.0
    f1        = round(2*prec*rec/(prec+rec),4) if (prec+rec)>0 else 0.0
    return {
        'score':       len(inter),
        'exact_match': int(resp_set == gt_set),
        'f1':          f1,
        'n_correct':   len(inter),
        'n_gt':        len(gt_set),
    }

def recompute_single(resp_str, gt_label, rank_map=None):
    r = norm(str(resp_str)) if pd.notna(resp_str) else ''
    g = norm(gt_label)
    correct = int(r == g)
    ord_dist = np.nan
    if rank_map:
        rr = rank_map.get(r, np.nan); gr = rank_map.get(g, np.nan)
        ord_dist = abs(rr-gr) if not (np.isnan(rr) or np.isnan(gr)) else np.nan
    return correct, ord_dist

def kripp(matrix, level='interval'):
    data = np.array(matrix, dtype=float)
    _, n_items = data.shape
    coincidences = []
    for item in range(n_items):
        col = data[:,item]; valid = col[~np.isnan(col)]
        if len(valid)<2: continue
        for i in range(len(valid)):
            for j in range(i+1,len(valid)):
                coincidences.append((valid[i],valid[j]))
    if not coincidences: return np.nan
    all_v = data[~np.isnan(data)]
    if len(all_v)<2: return np.nan
    def d(v1,v2): return 0.0 if v1==v2 else 1.0 if level=='nominal' else (v1-v2)**2
    Do = np.mean([d(a,b) for a,b in coincidences])
    n = len(all_v)
    De = np.sum([d(all_v[i],all_v[j]) for i in range(n) for j in range(i+1,n)])*2/(n*(n-1))
    return np.nan if De==0 else round(1.0-Do/De,4)

ORDINAL = {'low':0,'medium':1,'high':2}

# ── GT lookups ─────────────────────────────────────────────────────────────
gt_act['gt_set'] = gt_act['gt_answer'].apply(norm_set)
act_lkp = {(norm(r['study_design']),str(r['clip_id']).strip(),norm(r['question_type'])):r['gt_set']
           for _,r in gt_act.iterrows()}
eng_lkp = {(norm(r['study_design']),str(r['clip_id']).strip()):norm(str(r['gt_answer']))
           for _,r in gt_eng.iterrows()}
gaz_lkp = {(norm(r['study_design']),str(r['clip_id']).strip(),str(int(r['frame_idx']))):norm(str(r['gt_answer']))
           for _,r in gt_gaz.iterrows()}

# ── Col lookup maps ────────────────────────────────────────────────────────
WACT = {'Q20':('activity_type','anonymized_nosound'),'Q21':('actions_occurring','anonymized_nosound'),
        'Q26':('activity_type','anonymized'),        'Q29':('actions_occurring','anonymized'),
        'Q25':('activity_type','blurred'),           'Q27':('actions_occurring','blurred'),
        'Q24':('activity_type','raw'),               'Q28':('actions_occurring','raw')}
WENG = {'Q36':'anonymized_nosound','Q37':'anonymized','Q38':'blurred','Q39':'raw'}

q17={};q13={};q33={};q53={};wa={};we={}
for c in cols:
    i = cols.index(c)
    clip = str(qtxt[i]).split(' - ')[0].strip()
    if   '_Q17' in str(c): q17[clip]=c
    elif '_Q13' in str(c): q13[clip]=c
    elif '_Q33' in str(c): q33[clip]=c
    elif '_Q53' in str(c): q53[int(c.split('_')[0])]=clip
    else:
        for qs,(qt2,mod) in WACT.items():
            if c.endswith(f'_{qs}'): wa[(clip,qt2,mod)]=c; break
        for qs,mod in WENG.items():
            if c.endswith(f'_{qs}'): we[(clip,mod)]=c; break

def q53_pmap(prow):
    # Build clip+frame_idx -> candidate Q53 cols map
    # At scoring time, find which col has a response for this participant
    MODS = ['anonymized', 'blurred', 'raw']
    gt_gaz_v = pd.read_excel('/home/claude/scoring_pipeline/Scoring_Pipeline/ground_truth_labels.xlsx', sheet_name='Gaze', header=1)
    gt_between_v = gt_gaz_v[gt_gaz_v['study_design']=='between']
    c2q = defaultdict(list)
    for n, clip in q53.items(): c2q[clip].append(f'{n}_Q53')
    clip_groups = {}
    for clip, q53_cols in c2q.items():
        sorted_cols = sorted(q53_cols, key=lambda x: int(x.split('_')[0]))
        gt_frames   = sorted([int(f) for f in gt_between_v[gt_between_v['clip_id']==clip]['frame_idx'].tolist()])
        if len(gt_frames) == 1:
            clip_groups[clip] = {str(gt_frames[0]): sorted_cols}
        elif len(gt_frames) == 2:
            half = len(sorted_cols) // 2
            clip_groups[clip] = {
                str(gt_frames[0]): sorted_cols[:half],
                str(gt_frames[1]): sorted_cols[half:],
            }
    return clip_groups

def binary_expand_alpha(df, qt, mod):
    grp = df[(df['question_type']==qt) & (df['modality']==mod)].copy()
    is_actions = 'action' in qt.lower()

    if is_actions:
        # Binary expansion for actions_occurring
        all_options = sorted(set(
            norm(item)
            for resp in grp['participant_resp'].dropna()
            for item in str(resp).split(',')
            if norm(item) and norm(item) != 'nan'
        ))
        binary_cols = {}
        for (pid, clip), pgrp in grp.groupby(['participant_id','clip_id']):
            raw_resp = pgrp['participant_resp'].iloc[0]
            is_skip  = pd.isna(raw_resp) or str(raw_resp).strip() in ['', 'nan']
            selected = set(norm(i) for i in str(raw_resp).split(',') if norm(i) and norm(i)!='nan')
            for opt in all_options:
                key = f'{clip}::{opt}'
                if key not in binary_cols: binary_cols[key] = {}
                binary_cols[key][pid] = 0 if is_skip else (1 if opt in selected else 0)
        all_pids = grp['participant_id'].unique()
        matrix = [[binary_cols[col].get(pid, np.nan) for col in binary_cols] for pid in all_pids]
        return kripp(np.array(matrix, dtype=float), 'nominal')
    else:
        # Nominal Alpha on actual response string for activity_type
        all_resps = sorted(grp['participant_resp'].dropna().apply(norm).unique())
        resp_map  = {r: i for i, r in enumerate(all_resps)}
        grp['resp_num'] = grp['participant_resp'].apply(
            lambda x: resp_map.get(norm(x), np.nan) if pd.notna(x) else np.nan
        )
        pivot = grp.pivot_table(index='participant_id', columns='clip_id',
                                values='resp_num', aggfunc='first')
        return kripp(np.array(pivot.values, dtype=float), 'nominal')

total_errors = 0

# ══════════════════════════════════════════════════════════════════════════
print("=" * 70)
print("VERIFYING MODEL 1: Between Activity")
print("=" * 70)
m1 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model1_between_activity.xlsx', sheet_name='Scores')
irr1 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model1_between_activity.xlsx', sheet_name='IRR_Summary')

row_errors = 0
for _, row in m1.iterrows():
    pid=row['participant_id']; clip=str(row['clip_id']).strip(); qt=row['question_type']
    prow=data[data['ResponseId']==pid].iloc[0]
    q_col = q17.get(clip) if qt=='activity_type' else q13.get(clip)
    raw_resp = str(prow.get(q_col,'')).strip() if q_col else ''
    file_resp = str(row['participant_resp']).strip()
    # Check response
    if raw_resp != file_resp and not(raw_resp in ['nan',''] and file_resp==''):
        print(f"  ROW ERROR: pid={pid} clip={clip} qt={qt}: raw=[{raw_resp}] file=[{file_resp}]")
        row_errors += 1
    # Check metrics
    gt_set = act_lkp.get(('between', clip, qt), frozenset())
    expected = recompute_multiselect(raw_resp if raw_resp not in ['nan',''] else None, gt_set)
    for metric, exp_val in expected.items():
        if metric in row:
            file_val = row[metric]
            if abs(float(file_val) - float(exp_val)) > 0.0001:
                print(f"  METRIC ERROR: pid={pid} clip={clip} qt={qt} {metric}: expected={exp_val} file={file_val}")
                row_errors += 1

print(f"  Row+metric errors: {row_errors}")
total_errors += row_errors

# Verify IRR summary
print("  Verifying IRR summary...")
irr_errors = 0
for _, irr_row in irr1.iterrows():
    mod = irr_row['modality']; qt = irr_row['question_type']
    grp = m1[(m1['modality']==mod) & (m1['question_type']==qt)]
    exp_alpha = binary_expand_alpha(m1, qt, mod)
    is_actions = 'action' in qt.lower()
    checks = [('krippendorff_alpha', exp_alpha, irr_row['krippendorff_alpha'])]
    if is_actions:
        exp_f1  = round(grp['f1'].mean(),4)
        exp_acc = round(grp['exact_match'].mean(),4)
        checks += [('mean_f1', exp_f1, irr_row['mean_f1']),
                   ('exact_match_rate', exp_acc, irr_row['exact_match_rate'])]
    else:
        # activity_type: accuracy only
        exp_acc = round(grp['score'].mean(),4)
        checks += [('accuracy', exp_acc, irr_row.get('accuracy', np.nan))]
    for field, exp, file_val in checks:
        if pd.isna(exp) and pd.isna(file_val): continue
        if pd.isna(exp) or pd.isna(file_val) or abs(float(exp)-float(file_val))>0.0001:
            print(f"  IRR ERROR: mod={mod} qt={qt} {field}: expected={exp} file={file_val}")
            irr_errors += 1
print(f"  IRR errors: {irr_errors}")
total_errors += irr_errors

# ══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("VERIFYING MODEL 2: Between Engagement")
print("=" * 70)
m2 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model2_between_engagement.xlsx', sheet_name='Scores')
irr2 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model2_between_engagement.xlsx', sheet_name='IRR_Summary')

row_errors = 0
for _, row in m2.iterrows():
    pid=row['participant_id']; clip=str(row['clip_id']).strip()
    prow=data[data['ResponseId']==pid].iloc[0]
    q_col=q33.get(clip)
    raw_resp=str(prow.get(q_col,'')).strip() if q_col else ''
    file_resp=str(row['participant_resp']).strip()
    if norm(raw_resp)!=file_resp and not(raw_resp in ['nan',''] and file_resp==''):
        print(f"  ROW ERROR: pid={pid} clip={clip}: raw=[{raw_resp}] file=[{file_resp}]")
        row_errors+=1
    gt_label=eng_lkp.get(('between',clip),'')
    exp_c, exp_od = recompute_single(raw_resp if raw_resp not in ['nan',''] else None, gt_label, ORDINAL)
    if row['correct'] != exp_c:
        print(f"  METRIC ERROR: correct expected={exp_c} file={row['correct']}")
        row_errors+=1
    if not pd.isna(exp_od) and not pd.isna(row['ordinal_distance']):
        if abs(float(exp_od)-float(row['ordinal_distance']))>0.0001:
            print(f"  METRIC ERROR: ordinal_dist expected={exp_od} file={row['ordinal_distance']}")
            row_errors+=1

print(f"  Row+metric errors: {row_errors}")
total_errors += row_errors

irr_errors=0
for _, irr_row in irr2.iterrows():
    mod=irr_row['modality']
    grp=m2[m2['modality']==mod].copy()
    grp['resp_rank']=grp['participant_resp'].map(ORDINAL)
    pivot=grp.pivot_table(index='participant_id',columns='clip_id',values='resp_rank',aggfunc='first')
    exp_alpha=kripp(pivot.values,'ordinal')
    exp_acc=round(grp['correct'].mean(),4)
    for field,exp,fv in [('krippendorff_alpha',exp_alpha,irr_row['krippendorff_alpha']),
                          ('accuracy',exp_acc,irr_row['accuracy'])]:
        if pd.isna(exp) and pd.isna(fv): continue
        if pd.isna(exp) or pd.isna(fv) or abs(float(exp)-float(fv))>0.0001:
            print(f"  IRR ERROR: mod={mod} {field}: expected={exp} file={fv}")
            irr_errors+=1
print(f"  IRR errors: {irr_errors}")
total_errors+=irr_errors

# ══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("VERIFYING MODEL 3: Between Gaze")
print("=" * 70)
m3 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model3_between_gaze.xlsx', sheet_name='Scores')
irr3 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model3_between_gaze.xlsx', sheet_name='IRR_Summary')

row_errors=0
clip_groups = q53_pmap(None)  # build once
for _,row in m3.iterrows():
    pid=row['participant_id']; clip=str(row['clip_id']).strip()
    fidx=str(int(row['frame_idx'])); mod=str(row['modality']).strip().lower()
    prow=data[data['ResponseId']==pid].iloc[0]
    # Find which candidate col has a response for this participant
    candidates = clip_groups.get(clip, {}).get(fidx, [])
    q_col = None; raw_resp = ''
    for cand in candidates:
        val = prow.get(cand,'')
        if pd.notna(val) and str(val).strip() not in ['','nan']:
            q_col = cand; raw_resp = str(val).strip(); break
    file_resp=str(row['participant_resp']).strip()
    # Treat both empty string and 'nan' as no-response for comparison
    raw_no_resp  = raw_resp  in ['', 'nan']
    file_no_resp = file_resp in ['', 'nan']
    if not (raw_no_resp and file_no_resp) and norm(raw_resp) != file_resp:
        print(f"  ROW ERROR: pid={pid} clip={clip} fidx={fidx} mod={mod}: raw=[{raw_resp}] file=[{file_resp}]")
        row_errors+=1
    gt_label=gaz_lkp.get(('between',clip,fidx),'')
    exp_c,_ = recompute_single(raw_resp if raw_resp not in ['nan',''] else None, gt_label)
    if row['correct']!=exp_c:
        print(f"  METRIC ERROR: correct expected={exp_c} file={row['correct']}")
        row_errors+=1

print(f"  Row+metric errors: {row_errors}")
total_errors+=row_errors

irr_errors=0
for _,irr_row in irr3.iterrows():
    mod=irr_row['modality']
    grp=m3[m3['modality']==mod].copy()
    grp['resp_num']=pd.to_numeric(grp['participant_resp'].str.replace('id ','').str.strip(),errors='coerce')
    grp['item_key']=grp['clip_id'].astype(str)+'_'+grp['frame_idx'].astype(str)
    pivot=grp.pivot_table(index='participant_id',columns='item_key',values='resp_num',aggfunc='first')
    exp_alpha=kripp(pivot.values,'nominal')
    exp_acc=round(grp['correct'].mean(),4)
    for field,exp,fv in [('krippendorff_alpha',exp_alpha,irr_row['krippendorff_alpha']),
                          ('accuracy',exp_acc,irr_row['accuracy'])]:
        if pd.isna(exp) and pd.isna(fv): continue
        if pd.isna(exp) or pd.isna(fv) or abs(float(exp)-float(fv))>0.0001:
            print(f"  IRR ERROR: mod={mod} {field}: expected={exp} file={fv}")
            irr_errors+=1
print(f"  IRR errors: {irr_errors}")
total_errors+=irr_errors

# ══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("VERIFYING MODEL 4: Within Activity")
print("=" * 70)
m4 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model4_within_activity.xlsx', sheet_name='Scores')
irr4 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model4_within_activity.xlsx', sheet_name='IRR_Summary')

row_errors=0
for _,row in m4.iterrows():
    pid=row['participant_id']; clip=str(row['clip_id']).strip()
    qt=row['question_type']; mod=row['modality']
    prow=data[data['ResponseId']==pid].iloc[0]
    q_col=wa.get((clip,qt,mod))
    raw_resp=str(prow.get(q_col,'')).strip() if q_col else ''
    file_resp=str(row['participant_resp']).strip()
    if raw_resp!=file_resp and not(raw_resp in ['nan',''] and file_resp==''):
        print(f"  ROW ERROR: pid={pid} clip={clip} qt={qt} mod={mod}: raw=[{raw_resp}] file=[{file_resp}]")
        row_errors+=1
    gt_set=act_lkp.get(('within',clip,qt),frozenset())
    expected=recompute_multiselect(raw_resp if raw_resp not in ['nan',''] else None, gt_set)
    for metric,exp_val in expected.items():
        if metric in row:
            if abs(float(row[metric])-float(exp_val))>0.0001:
                print(f"  METRIC ERROR: pid={pid} clip={clip} qt={qt} mod={mod} {metric}: expected={exp_val} file={row[metric]}")
                row_errors+=1

print(f"  Row+metric errors: {row_errors}")
total_errors+=row_errors

irr_errors=0
for _,irr_row in irr4.iterrows():
    mod=irr_row['modality']; qt=irr_row['question_type']
    grp=m4[(m4['modality']==mod)&(m4['question_type']==qt)]
    exp_alpha=binary_expand_alpha(m4, qt, mod)
    is_actions='action' in qt.lower()
    checks=[('krippendorff_alpha',exp_alpha,irr_row['krippendorff_alpha'])]
    if is_actions:
        exp_f1=round(grp['f1'].mean(),4)
        checks.append(('mean_f1',exp_f1,irr_row['mean_f1']))
    else:
        exp_acc=round(grp['score'].mean(),4)
        checks.append(('accuracy',exp_acc,irr_row.get('accuracy',np.nan)))
    for field,exp,fv in checks:
        if pd.isna(exp) and pd.isna(fv): continue
        if pd.isna(exp) or pd.isna(fv) or abs(float(exp)-float(fv))>0.0001:
            print(f"  IRR ERROR: mod={mod} qt={qt} {field}: expected={exp} file={fv}")
            irr_errors+=1
print(f"  IRR errors: {irr_errors}")
total_errors+=irr_errors

# ══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("VERIFYING MODEL 5: Within Engagement")
print("=" * 70)
m5 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model5_within_engagement.xlsx', sheet_name='Scores')
irr5 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model5_within_engagement.xlsx', sheet_name='IRR_Summary')

row_errors=0
for _,row in m5.iterrows():
    pid=row['participant_id']; clip=str(row['clip_id']).strip(); mod=row['modality']
    prow=data[data['ResponseId']==pid].iloc[0]
    q_col=we.get((clip,mod))
    raw_resp=str(prow.get(q_col,'')).strip() if q_col else ''
    file_resp=str(row['participant_resp']).strip()
    if norm(raw_resp)!=file_resp and not(raw_resp in ['nan',''] and file_resp==''):
        print(f"  ROW ERROR: pid={pid} clip={clip} mod={mod}: raw=[{raw_resp}] file=[{file_resp}]")
        row_errors+=1
    gt_label=eng_lkp.get(('within',clip),'')
    exp_c,exp_od=recompute_single(raw_resp if raw_resp not in ['nan',''] else None, gt_label, ORDINAL)
    if row['correct']!=exp_c:
        print(f"  METRIC ERROR: correct expected={exp_c} file={row['correct']}")
        row_errors+=1
    if not pd.isna(exp_od) and not pd.isna(row['ordinal_distance']):
        if abs(float(exp_od)-float(row['ordinal_distance']))>0.0001:
            print(f"  METRIC ERROR: ord_dist expected={exp_od} file={row['ordinal_distance']}")
            row_errors+=1

print(f"  Row+metric errors: {row_errors}")
total_errors+=row_errors

irr_errors=0
for _,irr_row in irr5.iterrows():
    mod=irr_row['modality']
    grp=m5[m5['modality']==mod].copy()
    grp['resp_rank']=grp['participant_resp'].map(ORDINAL)
    pivot=grp.pivot_table(index='participant_id',columns='clip_id',values='resp_rank',aggfunc='first')
    exp_alpha=kripp(pivot.values,'ordinal')
    exp_acc=round(grp['correct'].mean(),4)
    for field,exp,fv in [('krippendorff_alpha',exp_alpha,irr_row['krippendorff_alpha']),
                          ('accuracy',exp_acc,irr_row['accuracy'])]:
        if pd.isna(exp) and pd.isna(fv): continue
        if pd.isna(exp) or pd.isna(fv) or abs(float(exp)-float(fv))>0.0001:
            print(f"  IRR ERROR: mod={mod} {field}: expected={exp} file={fv}")
            irr_errors+=1
print(f"  IRR errors: {irr_errors}")
total_errors+=irr_errors

# ══════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("VERIFYING MODEL 6: Within Gaze")
print("=" * 70)
m6 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model6_within_gaze.xlsx', sheet_name='Scores')
irr6 = pd.read_excel('/home/claude/scoring_pipeline/output_new/model6_within_gaze.xlsx', sheet_name='IRR_Summary')

row_errors=0
for _,row in m6.iterrows():
    pid=row['participant_id']; n=int(row['item_n'])
    clip=str(row['clip_id']).strip(); fidx=str(int(row['frame_idx']))
    prow=data[data['ResponseId']==pid].iloc[0]
    raw_resp=str(prow.get(f'{n}_Q56','')).strip()
    file_resp=str(row['participant_resp']).strip()
    if norm(raw_resp)!=file_resp and not(raw_resp in ['nan',''] and file_resp==''):
        print(f"  ROW ERROR: pid={pid} n={n}: raw=[{raw_resp}] file=[{file_resp}]")
        row_errors+=1
    gt_label=gaz_lkp.get(('within',clip,fidx),'')
    exp_c,_=recompute_single(raw_resp if raw_resp not in ['nan',''] else None, gt_label)
    if row['correct']!=exp_c:
        print(f"  METRIC ERROR: correct expected={exp_c} file={row['correct']}")
        row_errors+=1

print(f"  Row+metric errors: {row_errors}")
total_errors+=row_errors

irr_errors=0
for _,irr_row in irr6.iterrows():
    mod=irr_row['modality']
    grp=m6[m6['modality']==mod].copy()
    grp['resp_num']=pd.to_numeric(grp['participant_resp'].str.replace('id ','').str.strip(),errors='coerce')
    grp['item_key']=grp['clip_id'].astype(str)+'_'+grp['frame_idx'].astype(str)
    pivot=grp.pivot_table(index='participant_id',columns='item_key',values='resp_num',aggfunc='first')
    exp_alpha=kripp(pivot.values,'nominal')
    exp_acc=round(grp['correct'].mean(),4)
    for field,exp,fv in [('krippendorff_alpha',exp_alpha,irr_row['krippendorff_alpha']),
                          ('accuracy',exp_acc,irr_row['accuracy'])]:
        if pd.isna(exp) and pd.isna(fv): continue
        if pd.isna(exp) or pd.isna(fv) or abs(float(exp)-float(fv))>0.0001:
            print(f"  IRR ERROR: mod={mod} {field}: expected={exp} file={fv}")
            irr_errors+=1
print(f"  IRR errors: {irr_errors}")
total_errors+=irr_errors

# ── Final ──────────────────────────────────────────────────────────────────
print("\n" + "=" * 70)
print(f"FINAL RESULT: {total_errors} total errors across all 6 models")
if total_errors == 0:
    print("ALL VERIFIED — every response, every metric, every IRR value correct.")
print("=" * 70)
