import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

m1b = pd.read_excel('/home/claude/scoring_pipeline/output_new/model1_between_activity.xlsx',   sheet_name='Scores')
m2b = pd.read_excel('/home/claude/scoring_pipeline/output_new/model2_between_engagement.xlsx', sheet_name='Scores')
m3b = pd.read_excel('/home/claude/scoring_pipeline/output_new/model3_between_gaze.xlsx',       sheet_name='Scores')
m4w = pd.read_excel('/home/claude/scoring_pipeline/output_new/model4_within_activity.xlsx',    sheet_name='Scores')
m5w = pd.read_excel('/home/claude/scoring_pipeline/output_new/model5_within_engagement.xlsx',  sheet_name='Scores')
m6w = pd.read_excel('/home/claude/scoring_pipeline/output_new/model6_within_gaze.xlsx',        sheet_name='Scores')

BLUE='FF2F5496'; LBLUE='FFD9E2F3'; GREEN='FF375623'; LGREEN='FFE2EFDA'
ORANGE='FF833C00'; LORANGE='FFFCE4D6'; GREY='FFD9D9D9'; WHITE='FFFFFFFF'
LRED='FFFFC7CE'; NAVY='FF1F3864'

thin = Side(style='thin', color='FFAAAAAA')
brd  = Border(left=thin, right=thin, top=thin, bottom=thin)
ctr  = Alignment(horizontal='center', vertical='center', wrap_text=True)
lft  = Alignment(horizontal='left',   vertical='center', wrap_text=True)

def sc(cell, text='', bold=False, fill=WHITE, color='FF000000', size=10, align=None):
    cell.value     = str(text)
    cell.font      = Font(name='Arial', bold=bold, color=color, size=size)
    cell.fill      = PatternFill('solid', fgColor=fill)
    cell.alignment = align or lft
    cell.border    = brd

def shdr(cell, text):
    sc(cell, text, bold=True, fill=GREY, color='FF000000', align=ctr)

def title(ws, row, text, fill, ncols=8):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    sc(ws.cell(row=row, column=1), text, bold=True, fill=fill, color='FFFFFFFF', size=12, align=ctr)
    ws.row_dimensions[row].height = 22

def note(ws, row, text, ncols=8):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1)
    c.value     = text
    c.font      = Font(name='Arial', italic=True, size=9, color='FF555555')
    c.alignment = lft
    ws.row_dimensions[row].height = 14

def shorten(df):
    df  = df.copy()
    pm  = {pid: 'P'+str(i+1) for i, pid in enumerate(df['participant_id'].unique())}
    df['participant_id'] = df['participant_id'].map(pm)
    return df

wb = Workbook()

# ── SHEET 1: HOW TO READ ──────────────────────────────────────────────────
ws0 = wb.active
ws0.title = 'How to Read This File'
ws0.column_dimensions['A'].width = 24
ws0.column_dimensions['B'].width = 50
ws0.column_dimensions['C'].width = 45

n_p = m1b['participant_id'].nunique()
title(ws0, 1, f'How to Read This Results File — Video Anonymization Pilot (n={n_p})', BLUE, ncols=3)
note(ws0, 2, f'Results are for pipeline validation only. Do not interpret modality differences with only {n_p} participants.', ncols=3)

for c, h in enumerate(['Metric', 'What it means', 'How to verify from raw data'], 1):
    shdr(ws0.cell(row=4, column=c), h)

metrics = [
    ('score (activity)',
     'Correct items selected out of the GT total for that clip (e.g. 2/4 means 2 correct out of 4 GT items). Denominator varies per clip since each clip has a different number of correct answers.',
     'Count items in participant_resp that also appear in gt_answer. GT Items column shows the denominator.'),
    ('accuracy (activity_type — primary metric)',
     'Proportion of correct responses for activity_type. Since activity_type is a single forced choice, accuracy is the appropriate metric. Range 0-1, where 1 = all participants selected the correct activity type.',
     'accuracy = number of correct responses / total responses for that modality. correct=1 when participant_resp matches gt_answer.'),
    ('f1 (actions_occurring — primary metric)',
     'Balances missing correct items (low recall) and selecting wrong items (low precision). Range 0-1. Comparable across clips regardless of how many GT items each clip has. Used for actions_occurring (multi-select) only.',
     'f1 = 2*(precision*recall)/(precision+recall). Precision=correct/selected. Recall=correct/gt_total.'),
    ('correct (engagement/gaze)',
     '1 if response matches GT exactly, 0 if not.',
     'Check participant_resp == gt_answer.'),
    ('ordinal_distance (engagement)',
     'How far off on Low/Medium/High scale. 0=correct, 1=one level off (e.g. Low vs Medium), 2=two levels off (Low vs High).',
     'Low=0, Medium=1, High=2. Distance = |rank(response) - rank(gt_answer)|.'),
    ('krippendorff_alpha (IRR)',
     'Agreement between participants who saw the SAME clip+modality (between-subjects) or the same clip (within-subjects). 1=perfect, 0=chance, <0=worse than chance. NaN=undefined when all responses are identical (De=0) or fewer than 2 raters per item.',
     'Alpha = 1 - (Do/De). Do=observed disagreement, De=expected disagreement by chance. Nominal for activity/gaze, ordinal for engagement, binary expansion for actions_occurring.'),
    ('modality imbalance note (between-subjects)',
     'In the between-subjects design each participant is randomly assigned one modality per clip. With 40 participants some modalities may receive fewer assignments by chance (e.g. blurred received 120 assignments vs 160 for other modalities for between-subjects activity). This can affect comparability of results across modalities.',
     'Check Clip_n_Modality columns in raw Qualtrics CSV to see modality distribution per clip.'),
]
for i, (m, w, v) in enumerate(metrics, 5):
    fill = LBLUE if i % 2 == 0 else WHITE
    sc(ws0.cell(row=i, column=1), m, bold=True, fill=fill)
    sc(ws0.cell(row=i, column=2), w, fill=fill)
    sc(ws0.cell(row=i, column=3), v, fill=fill)
    ws0.row_dimensions[i].height = 45

nr = 5 + len(metrics) + 1
ws0.merge_cells(start_row=nr, start_column=1, end_row=nr, end_column=3)
c = ws0.cell(row=nr, column=1)
c.value = f'NOTE: Between-subjects modality assignment is random. With {n_p} participants some clips may have unequal modality distributions which can affect comparability of results across modalities.'
c.font  = Font(name='Arial', bold=True, size=10, color='FFCC0000')
c.fill  = PatternFill('solid', fgColor=LRED)
c.alignment = lft
c.border = brd
ws0.row_dimensions[nr].height = 25


# ── ACTIVITY SHEETS ───────────────────────────────────────────────────────
def write_act_sheet(ws, df, design):
    df = shorten(df)
    for col, wid in enumerate([5,32,22,14,10,6,6,38,38], 1):
        ws.column_dimensions[get_column_letter(col)].width = wid
    fill_sec = BLUE if design == 'Between' else GREEN
    note_text_between = 'Modality randomly assigned per participant. Score = correct items out of GT total for that clip. Accuracy is the primary metric for activity_type. F1 is the primary metric for actions_occurring.'
    note_text_within  = 'Every participant sees every clip under all 4 modalities. Score = correct items out of GT total for that clip. Accuracy is the primary metric for activity_type. F1 is the primary metric for actions_occurring.'
    title(ws, 1, design+'-Subjects Activity — Individual Participant Scores', fill_sec, ncols=9)
    note(ws, 2, note_text_between if design == 'Between' else note_text_within, ncols=9)

    for qt, label in [('activity_type',    'Q1: Activity Type (max 4 choices — score varies by clip)'),
                      ('actions_occurring', 'Q2: Actions Occurring (max 8 choices — score varies by clip)')]:
        # activity_type: show exact_match (meaningful). actions_occurring: drop it (almost always 0)
        show_exact = (qt == 'activity_type')
        if show_exact:
            hdrs = ['P', 'Clip ID', 'Modality', 'Score (out of GT)', 'GT Items', 'Exact Match', 'F1', 'GT Answer', 'Participant Response']
            ncols_t = 9
        else:
            hdrs = ['P', 'Clip ID', 'Modality', 'Score (out of GT)', 'GT Items', 'F1', '', 'GT Answer', 'Participant Response']
            ncols_t = 9
        r = ws.max_row + 2
        title(ws, r, label, fill_sec, ncols=ncols_t)
        r += 1
        for c, h in enumerate(hdrs, 1):
            shdr(ws.cell(row=r, column=c), h)
        r += 1
        fill_alt = LBLUE if design == 'Between' else LGREEN
        subset = df[df['question_type'] == qt].sort_values(['clip_id', 'modality', 'participant_id'])
        for i, (_, row) in enumerate(subset.iterrows()):
            fill = fill_alt if i % 2 == 0 else WHITE
            score_str = str(int(row['score'])) + '/' + str(int(row['n_gt']))
            if show_exact:
                vals = [row['participant_id'], row['clip_id'], row['modality'],
                        score_str, int(row['n_gt']), int(row['exact_match']),
                        round(row['f1'], 2), row['gt_answer'], row['participant_resp']]
            else:
                vals = [row['participant_id'], row['clip_id'], row['modality'],
                        score_str, int(row['n_gt']), round(row['f1'], 2),
                        '', row['gt_answer'], row['participant_resp']]
            for c, val in enumerate(vals, 1):
                sc(ws.cell(row=r, column=c), val, fill=fill)
            r += 1

    if design == 'Between':
        r = ws.max_row + 2
        all_pids = list(df['participant_id'].unique())
        pid_labels = {pid: f'P{i+1}' for i, pid in enumerate(all_pids)}
        n_pids = len(all_pids)
        ncols_irr = 3 + n_pids * 2  # clip/mod/qt + n scores + n F1s
        # Set column widths for participant columns
        for col in range(4, ncols_irr + 1):
            ws.column_dimensions[get_column_letter(col)].width = 10
        title(ws, r, 'IRR: Cells with 2+ participants seeing same clip + modality', GREY, ncols=ncols_irr)
        r += 1
        hdrs = ['Clip ID', 'Modality', 'Q Type'] + \
               [f'{pid_labels[p]} Score' for p in all_pids] + \
               [f'{pid_labels[p]} F1' for p in all_pids]
        for c, h in enumerate(hdrs, 1):
            shdr(ws.cell(row=r, column=c), h)
        r += 1
        shared = df.groupby(['clip_id', 'modality', 'question_type']).filter(lambda x: len(x) >= 2)
        for (cid, mod, qt), grp in shared.groupby(['clip_id', 'modality', 'question_type']):
            pid_to_score = {row['participant_id']: str(int(row['score']))+'/'+str(int(row['n_gt']))
                            for _, row in grp.iterrows()}
            pid_to_f1    = {row['participant_id']: str(round(row['f1'], 2))
                            for _, row in grp.iterrows()}
            scores = [pid_to_score.get(p, '') for p in all_pids]
            f1s    = [pid_to_f1.get(p,    '') for p in all_pids]
            valid_scores = [s for s in grp['score'].tolist()]
            agreed = len(valid_scores) >= 2 and len(set(valid_scores)) == 1
            row_d  = [cid, mod, qt] + scores + f1s
            for c, val in enumerate(row_d, 1):
                sc(ws.cell(row=r, column=c), val, fill=LGREEN if agreed else LRED)
            r += 1
        note(ws, r+1, 'Green=participants gave same score. Red=participants gave different scores.', ncols=ncols_irr)


# ── ENGAGEMENT SHEETS ─────────────────────────────────────────────────────
def write_eng_sheet(ws, df, design):
    df = shorten(df)
    for col, wid in enumerate([5, 22, 22, 14, 14, 12, 14], 1):
        ws.column_dimensions[get_column_letter(col)].width = wid
    title(ws, 1, design+'-Subjects Engagement — Individual Participant Scores', ORANGE, ncols=7)
    note(ws, 2, 'Single choice ordinal (Low/Medium/High). Correct=1 exact match. Ordinal distance: 0=correct, 1=one level off, 2=two levels off.', ncols=7)
    r = ws.max_row + 2
    for c, h in enumerate(['P', 'Clip ID', 'Modality', 'GT Answer', 'Response', 'Correct (0/1)', 'Ordinal Distance'], 1):
        shdr(ws.cell(row=r, column=c), h)
    r += 1
    for i, (_, row) in enumerate(df.sort_values(['clip_id', 'modality', 'participant_id']).iterrows()):
        fill = LORANGE if i % 2 == 0 else WHITE
        for c, val in enumerate([row['participant_id'], row['clip_id'], row['modality'],
                                  row['gt_answer'], row['participant_resp'],
                                  int(row['correct']),
                                  int(row['ordinal_distance']) if pd.notna(row['ordinal_distance']) else ''], 1):
            sc(ws.cell(row=r, column=c), val, fill=fill)
        r += 1

    if design == 'Between':
        r = ws.max_row + 2
        all_pids = list(df['participant_id'].unique())
        pid_labels = {pid: f'P{i+1}' for i, pid in enumerate(all_pids)}
        n_pids = len(all_pids)
        ncols_irr = 3 + n_pids * 2  # clip/mod/gt + n responses + n corrects
        for col in range(4, ncols_irr + 1):
            ws.column_dimensions[get_column_letter(col)].width = 14
        title(ws, r, 'IRR: Cells with 2+ participants seeing same clip + modality', GREY, ncols=ncols_irr)
        r += 1
        hdrs = ['Clip ID', 'Modality', 'GT'] + \
               [f'{pid_labels[p]} Response' for p in all_pids] + \
               [f'{pid_labels[p]} Correct' for p in all_pids]
        for c, h in enumerate(hdrs, 1):
            shdr(ws.cell(row=r, column=c), h)
        r += 1
        shared = df.groupby(['clip_id', 'modality']).filter(lambda x: len(x) >= 2)
        for (cid, mod), grp in shared.groupby(['clip_id', 'modality']):
            pid_to_resp    = {row['participant_id']: row['participant_resp']  for _, row in grp.iterrows()}
            pid_to_correct = {row['participant_id']: str(int(row['correct'])) for _, row in grp.iterrows()}
            resps   = [pid_to_resp.get(p,    '') for p in all_pids]
            corrects= [pid_to_correct.get(p, '') for p in all_pids]
            valid_resps = [str(r).strip() for r in grp['participant_resp'].tolist()
                           if pd.notna(r) and str(r).strip() not in ['', 'nan']]
            agreed  = len(valid_resps) >= 2 and len(set(valid_resps)) == 1
            row_d   = [cid, mod, grp['gt_answer'].iloc[0]] + resps + corrects
            for c, val in enumerate(row_d, 1):
                sc(ws.cell(row=r, column=c), val, fill=LGREEN if agreed else LRED)
            r += 1
        note(ws, r+1, 'Green=all participants gave same response. Red=participants disagreed.', ncols=ncols_irr)


# ── GAZE SHEETS ───────────────────────────────────────────────────────────
def write_gaze_sheet(ws, df, design):
    df = shorten(df)
    for col, wid in enumerate([5, 32, 10, 20, 10, 14, 12], 1):
        ws.column_dimensions[get_column_letter(col)].width = wid
    title(ws, 1, design+'-Subjects Gaze Direction — Individual Participant Scores', NAVY, ncols=7)
    if design == 'Between':
        note(ws, 2, 'Single choice (ID 1-4 = person teacher is looking at). Modality randomly assigned per participant.', ncols=7)
    else:
        note(ws, 2, 'Single choice (ID 1-4). Every participant sees every clip under 3 modalities (anonymized, blurred, raw).', ncols=7)
    r = ws.max_row + 2
    for c, h in enumerate(['P', 'Clip ID', 'Frame Idx', 'Modality', 'GT', 'Response', 'Correct (0/1)'], 1):
        shdr(ws.cell(row=r, column=c), h)
    r += 1
    for i, (_, row) in enumerate(df.sort_values(['clip_id', 'frame_idx', 'modality', 'participant_id']).iterrows()):
        fill = LBLUE if i % 2 == 0 else WHITE
        for c, val in enumerate([row['participant_id'], str(row['clip_id']),
                                  str(int(row['frame_idx'])), row['modality'],
                                  row['gt_answer'], row['participant_resp'], int(row['correct'])], 1):
            sc(ws.cell(row=r, column=c), val, fill=fill)
        r += 1
    if design == 'Between':
        r = ws.max_row + 2
        title(ws, r, 'IRR: Cells with 2+ participants seeing same clip+frame+modality (Green=agreed, Red=disagreed)', GREY, ncols=7)
        r += 1
        for c, h in enumerate(['Clip ID', 'Frame Idx', 'Modality', 'Participants', 'GT', 'All Responses', 'Agreed?'], 1):
            shdr(ws.cell(row=r, column=c), h)
        r += 1
        shared = df.groupby(['clip_id', 'frame_idx', 'modality']).filter(lambda x: len(x) >= 2)
        for (cid, fidx, mod), grp in shared.groupby(['clip_id', 'frame_idx', 'modality']):
            resps  = ' / '.join([str(x) if (pd.notna(x) and str(x).strip() != '') else 'no response' for x in grp['participant_resp'].tolist()])
            valid_resps = [str(x).strip() for x in grp['participant_resp'].tolist()
                           if pd.notna(x) and str(x).strip() not in ['', 'nan', 'no response']]
            agreed = len(valid_resps) >= 2 and len(set(valid_resps)) == 1
            for c, val in enumerate([str(cid), str(int(fidx)), mod,
                                      ' / '.join(grp['participant_id'].tolist()),
                                      grp['gt_answer'].iloc[0], resps,
                                      'Yes' if agreed else 'No'], 1):
                sc(ws.cell(row=r, column=c), val, fill=LGREEN if agreed else LRED)
            r += 1
        note(ws, r+1, 'Green=all participants gave same answer. Red=participants disagreed.', ncols=7)


ws1 = wb.create_sheet('Between — Activity');   write_act_sheet(ws1, m1b, 'Between')
ws2 = wb.create_sheet('Between — Engagement'); write_eng_sheet(ws2, m2b, 'Between')
ws3 = wb.create_sheet('Between — Gaze');       write_gaze_sheet(ws3, m3b, 'Between')
ws4 = wb.create_sheet('Within — Activity');    write_act_sheet(ws4, m4w, 'Within')
ws5 = wb.create_sheet('Within — Engagement');  write_eng_sheet(ws5, m5w, 'Within')
ws6 = wb.create_sheet('Within — Gaze');        write_gaze_sheet(ws6, m6w, 'Within')

# ── IRR SUMMARY SHEET ─────────────────────────────────────────────────────
ws_irr = wb.create_sheet('IRR Summary')
for col, wid in enumerate([20, 22, 18, 16, 12, 12, 12, 12, 12], 1):
    ws_irr.column_dimensions[get_column_letter(col)].width = wid

title(ws_irr, 1, 'Inter-Rater Reliability (IRR) Summary — Krippendorff Alpha per Modality', BLUE, ncols=9)
note(ws_irr, 2,
     'Alpha per modality = agreement across all participants who saw the same clip+modality. '
     '1=perfect, 0=chance, <0=worse than chance, NaN=fewer than 2 participants in that cell.',
     ncols=9)
note(ws_irr, 3,
     'Between-subjects: participants randomly assigned one modality per clip. '
     'Within-subjects: every participant saw every clip under every modality.',
     ncols=9)

models = [
    ('Between — Activity',   '/home/claude/scoring_pipeline/output_new/model1_between_activity.xlsx',   BLUE),
    ('Between — Engagement', '/home/claude/scoring_pipeline/output_new/model2_between_engagement.xlsx', ORANGE),
    ('Between — Gaze',       '/home/claude/scoring_pipeline/output_new/model3_between_gaze.xlsx',       NAVY),
    ('Within — Activity',    '/home/claude/scoring_pipeline/output_new/model4_within_activity.xlsx',    GREEN),
    ('Within — Engagement',  '/home/claude/scoring_pipeline/output_new/model5_within_engagement.xlsx',  ORANGE),
    ('Within — Gaze',        '/home/claude/scoring_pipeline/output_new/model6_within_gaze.xlsx',        NAVY),
]

r = 5
for model_name, path, fill in models:
    irr = pd.read_excel(path, sheet_name='IRR_Summary')
    keep = [c for c in ['question_type', 'modality', 'n_participants', 'n_clips',
                         'krippendorff_alpha', 'accuracy', 'mean_f1', 'mean_ordinal_dist']
            if c in irr.columns]
    irr = irr[keep]
    title(ws_irr, r, model_name, fill, ncols=len(keep))
    r += 1
    for c, h in enumerate(keep, 1):
        shdr(ws_irr.cell(row=r, column=c), h)
    r += 1
    fill_alt = LBLUE if 'Activity' in model_name else (LORANGE if 'Engagement' in model_name else 'FFD9E8F4')
    for i, (_, row) in enumerate(irr.iterrows()):
        rf = fill_alt if i % 2 == 0 else WHITE
        for c, val in enumerate(row.tolist(), 1):
            display = round(val, 4) if isinstance(val, float) and not pd.isna(val) \
                      else ('' if pd.isna(val) else val)
            sc(ws_irr.cell(row=r, column=c), display, fill=rf)
        r += 1
    r += 1

wb.save('/home/claude/scoring_pipeline/output_new/pilot_results_40participants.xlsx')
print('Saved.')
