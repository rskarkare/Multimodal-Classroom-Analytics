"""
Video Anonymization Study — Complete Scoring Pipeline
======================================================
6 Models:
  Model 1: Between-subjects Activity
  Model 2: Between-subjects Engagement
  Model 3: Between-subjects Gaze
  Model 4: Within-subjects Activity
  Model 5: Within-subjects Engagement
  Model 6: Within-subjects Gaze

RANDOMIZATION FIX (applies to Models 1-5):
  In Qualtrics Loop & Merge, clip order is randomized per participant.
  All question columns (Q17, Q13, Q33, Q53, Q20-Q28, Q36-Q39) have
  FIXED clip IDs hardcoded in the question text — same for all participants.
  The metadata columns (Clip_n_ID, Engage_n_ID, Frame_n_ID,
  Within_Clip_n_ID, Within_Engage_n_ID) record which clip was at
  position n FOR THAT SPECIFIC PARTICIPANT.

  Therefore position n in n_Q17 does NOT match Clip_n_ID for all
  participants. The correct approach is to look up the question column
  by matching clip_id (from metadata) to the clip_id in the question text.

  Model 6 (Within Gaze / Q56) is unaffected — Within_Frame_n_ID
  correctly matches n_Q56 for all participants.

All fixes verified: zero mismatches across all rows for all 6 models.
"""

import pandas as pd
import numpy as np
import warnings
from collections import defaultdict
warnings.filterwarnings('ignore')

GT_PATH     = '/home/claude/scoring_pipeline/Scoring_Pipeline/ground_truth_labels.xlsx'
DATA_PATH   = '/mnt/user-data/uploads/VideoAnonymization_PilotStudy_April_22__2026_18_15.csv'
OUT_DIR     = '/home/claude/scoring_pipeline/output_new'

ORDINAL_RANK = {'low': 0, 'medium': 1, 'high': 2}


# ── Krippendorff's Alpha ───────────────────────────────────────────────────

def krippendorff_alpha(reliability_matrix, level='interval'):
    data = np.array(reliability_matrix, dtype=float)
    _, n_items = data.shape
    coincidences = []
    for item in range(n_items):
        col   = data[:, item]
        valid = col[~np.isnan(col)]
        if len(valid) < 2:
            continue
        for i in range(len(valid)):
            for j in range(i + 1, len(valid)):
                coincidences.append((valid[i], valid[j]))
    if not coincidences:
        return np.nan
    all_values = data[~np.isnan(data)]
    if len(all_values) < 2:
        return np.nan
    def diff(v1, v2):
        if level == 'nominal':
            return 0.0 if v1 == v2 else 1.0
        return (v1 - v2) ** 2
    Do = np.mean([diff(a, b) for a, b in coincidences])
    n  = len(all_values)
    De = np.sum([diff(all_values[i], all_values[j])
                 for i in range(n)
                 for j in range(i + 1, n)]) * 2 / (n * (n - 1))
    if De == 0:
        return np.nan  # undefined: no variance in data, Alpha cannot be computed
    return round(1.0 - Do / De, 4)


# ── Text normalisation ─────────────────────────────────────────────────────

def normalise(text):
    if not isinstance(text, str):
        return ''
    return text.strip().rstrip('?').strip().lower()

def normalise_set(text):
    if not isinstance(text, str) or not text.strip():
        return frozenset()
    return frozenset(normalise(s) for s in text.split(',') if s.strip())


# ── Scoring ────────────────────────────────────────────────────────────────

def score_multiselect(response_str, gt_set):
    resp_set  = normalise_set(str(response_str)) if pd.notna(response_str) else frozenset()
    inter     = resp_set & gt_set
    union     = resp_set | gt_set
    precision = round(len(inter) / len(resp_set), 4) if resp_set else 0.0
    recall    = round(len(inter) / len(gt_set),   4) if gt_set   else 1.0
    f1        = round(2 * precision * recall / (precision + recall), 4) \
                if (precision + recall) > 0 else 0.0
    return {
        'score':       len(inter),
        'exact_match': int(resp_set == gt_set),
        'precision':   precision,
        'recall':      recall,
        'f1':          f1,
        'jaccard':     round(len(inter) / len(union), 4) if union else 1.0,
        'n_correct':   len(inter),
        'n_gt':        len(gt_set),
        'n_response':  len(resp_set),
    }

def score_single(response_str, gt_label, rank_map=None):
    resp_norm = normalise(str(response_str)) if pd.notna(response_str) else ''
    gt_norm   = normalise(gt_label)
    correct   = int(resp_norm == gt_norm)
    if rank_map:
        r_rank   = rank_map.get(resp_norm, np.nan)
        g_rank   = rank_map.get(gt_norm,   np.nan)
        ord_dist = abs(r_rank - g_rank) \
                   if not (np.isnan(r_rank) or np.isnan(g_rank)) else np.nan
    else:
        ord_dist = np.nan
    return {'correct': correct, 'ordinal_distance': ord_dist}


# ── IRR ────────────────────────────────────────────────────────────────────

def compute_irr_multiselect(scored_df, group_cols):
    """
    Compute Krippendorff's Alpha:
    - activity_type: nominal Alpha on actual response string (single forced choice)
    - actions_occurring: binary expansion — each action option is a separate binary question
    """
    rows = []
    for group_vals, grp in scored_df.groupby(group_cols):

        is_actions = 'question_type' in group_cols and \
                     any('action' in str(gv).lower()
                         for gv in (group_vals if isinstance(group_vals, tuple) else [group_vals]))

        if is_actions:
            # --- Binary expansion for actions_occurring ---
            all_options = sorted(set(
                normalise(item)
                for resp in grp['participant_resp'].dropna()
                for item in str(resp).split(',')
                if normalise(item) and normalise(item) != 'nan'
            ))
            binary_cols = {}
            for (pid, clip), pgrp in grp.groupby(['participant_id', 'clip_id']):
                raw_resp = pgrp['participant_resp'].iloc[0]
                is_skip  = pd.isna(raw_resp) or str(raw_resp).strip() in ['', 'nan']
                selected = set(
                    normalise(i) for i in str(raw_resp).split(',')
                    if normalise(i) and normalise(i) != 'nan'
                )
                for opt in all_options:
                    key = f'{clip}::{opt}'
                    if key not in binary_cols:
                        binary_cols[key] = {}
                    # NaN = selected no actions → treat as 0 for all actions
                    binary_cols[key][pid] = 0 if is_skip else (1 if opt in selected else 0)

            all_pids = grp['participant_id'].unique()
            matrix = [
                [binary_cols[col].get(pid, np.nan) for col in binary_cols]
                for pid in all_pids
            ]
            alpha = krippendorff_alpha(np.array(matrix, dtype=float), level='nominal')
            n_items = len(binary_cols)

        else:
            # --- Nominal Alpha on actual response string for activity_type ---
            all_resps = sorted(grp['participant_resp'].dropna().apply(normalise).unique())
            resp_map  = {r: i for i, r in enumerate(all_resps)}
            grp = grp.copy()
            grp['resp_num'] = grp['participant_resp'].apply(
                lambda x: resp_map.get(normalise(x), np.nan) if pd.notna(x) else np.nan
            )
            pivot = grp.pivot_table(index='participant_id', columns='clip_id',
                                    values='resp_num', aggfunc='first')
            alpha   = krippendorff_alpha(np.array(pivot.values, dtype=float), level='nominal')
            n_items = grp['clip_id'].nunique()

        max_sc = grp['max_score'].iloc[0]
        entry  = dict(zip(group_cols,
                          group_vals if isinstance(group_vals, tuple) else [group_vals]))
        if is_actions:
            entry.update({
                'max_possible_score': int(max_sc),
                'n_participants':     grp['participant_id'].nunique(),
                'n_clips':            grp['clip_id'].nunique(),
                'n_binary_items':     n_items,
                'krippendorff_alpha': alpha,
                'avg_score':          round(grp['score'].mean(), 4),
                'min_score':          int(grp['score'].min()),
                'max_score':          int(grp['score'].max()),
                'exact_match_rate':   round(grp['exact_match'].mean(), 4),
                'mean_f1':            round(grp['f1'].mean(), 4),
                'mean_recall':        round(grp['recall'].mean(), 4),
                'mean_precision':     round(grp['precision'].mean(), 4),
            })
        else:
            # activity_type is single forced choice — report accuracy not F1
            entry.update({
                'max_possible_score': int(max_sc),
                'n_participants':     grp['participant_id'].nunique(),
                'n_clips':            grp['clip_id'].nunique(),
                'n_binary_items':     n_items,
                'krippendorff_alpha': alpha,
                'accuracy':           round(grp['score'].mean(), 4),
            })
        rows.append(entry)
    return pd.DataFrame(rows)

def compute_irr_single(scored_df, group_cols, level='nominal', val_col=None):
    rows = []
    for group_vals, grp in scored_df.groupby(group_cols):
        # Determine value column for pivot:
        #   - caller can specify val_col explicitly (e.g. resp_num for gaze)
        #   - otherwise use resp_rank (engagement) or correct (other)
        if val_col is not None:
            use_col = val_col
        elif 'resp_rank' in grp.columns:
            use_col = 'resp_rank'
        else:
            use_col = 'correct'
        # For gaze models, use (clip_id, frame_idx) composite key
        # to handle multiple frames per clip with different frame indices
        if 'frame_idx' in grp.columns:
            grp = grp.copy()
            grp['item_key'] = grp['clip_id'].astype(str) + '_' + grp['frame_idx'].astype(str)
            col_key = 'item_key'
        else:
            col_key = 'clip_id'
        pivot   = grp.pivot_table(index='participant_id', columns=col_key,
                                  values=use_col, aggfunc='first')
        alpha   = krippendorff_alpha(pivot.values, level=level)
        entry   = dict(zip(group_cols,
                           group_vals if isinstance(group_vals, tuple) else [group_vals]))
        entry.update({
            'n_participants':     grp['participant_id'].nunique(),
            'n_clips':            grp['clip_id'].nunique(),
            'krippendorff_alpha': alpha,
            'accuracy':           round(grp['correct'].mean(), 4),
        })
        if 'ordinal_distance' in grp.columns:
            entry['mean_ordinal_dist'] = round(grp['ordinal_distance'].mean(), 4)
        rows.append(entry)
    return pd.DataFrame(rows)

def save_excel(scores_df, irr_df, path, score_cols):
    with pd.ExcelWriter(path, engine='openpyxl') as writer:
        scores_df[score_cols].to_excel(writer, sheet_name='Scores',      index=False)
        irr_df.to_excel(              writer, sheet_name='IRR_Summary',  index=False)
    print(f"  Saved: {path}  ({len(scores_df)} scored rows)")


# ── Build all question col lookup maps from question text ──────────────────

def build_col_lookups(col_names, question_texts):
    """
    Build clip_id -> question_col mappings from question text for all models.
    The clip ID is always the first part of the question text before ' - '.

    Returns dicts:
      q17_map  : clip_id -> col  (between activity type)
      q13_map  : clip_id -> col  (between actions occurring)
      q33_map  : clip_id -> col  (between engagement)
      q53_map  : position_n -> clip_id  (between gaze, for per-participant map)
      wa_map   : (clip_id, q_type, modality) -> col  (within activity)
      we_map   : (clip_id, modality) -> col  (within engagement)
    """
    q17_map = {}
    q13_map = {}
    q33_map = {}
    q53_pos_to_clip = {}

    # Within activity: Q-number -> (question_type, modality)
    WITHIN_ACT_Q_TO_TYPE_MOD = {
        'Q20': ('activity_type',    'anonymized_nosound'),
        'Q21': ('actions_occurring','anonymized_nosound'),
        'Q26': ('activity_type',    'anonymized'),
        'Q29': ('actions_occurring','anonymized'),
        'Q25': ('activity_type',    'blurred'),
        'Q27': ('actions_occurring','blurred'),
        'Q24': ('activity_type',    'raw'),
        'Q28': ('actions_occurring','raw'),
    }
    # Within engagement: Q-number -> modality
    WITHIN_ENG_Q_TO_MOD = {
        'Q36': 'anonymized_nosound',
        'Q37': 'anonymized',
        'Q38': 'blurred',
        'Q39': 'raw',
    }

    wa_map = {}
    we_map = {}

    for c in col_names:
        i    = col_names.index(c)
        clip = str(question_texts[i]).split(' - ')[0].strip()

        if   '_Q17' in str(c): q17_map[clip] = c
        elif '_Q13' in str(c): q13_map[clip] = c
        elif '_Q33' in str(c): q33_map[clip] = c
        elif '_Q53' in str(c):
            n = int(c.split('_')[0])
            q53_pos_to_clip[n] = clip
        else:
            for q_suffix, (q_type, mod) in WITHIN_ACT_Q_TO_TYPE_MOD.items():
                if c.endswith(f'_{q_suffix}'):
                    wa_map[(clip, q_type, mod)] = c
                    break
            for q_suffix, mod in WITHIN_ENG_Q_TO_MOD.items():
                if c.endswith(f'_{q_suffix}'):
                    we_map[(clip, mod)] = c
                    break

    return q17_map, q13_map, q33_map, q53_pos_to_clip, wa_map, we_map


def build_fixed_q53_map(q53_pos_to_clip, gt_gaz_df):
    """
    Build clip -> sorted list of Q53 cols grouped by frame_idx.

    Since the hash randomization means each participant may answer a different
    Q53 position for the same clip+frame_idx, we cannot use a fixed
    (clip, frame_idx, modality) -> Q53_col map. Instead we build a map of
    clip+frame_idx -> list of candidate Q53 cols, and at scoring time we
    find which one has a non-empty response for each participant.

    Returns: (clip_to_group, gt_between)
      clip_to_group: {clip: {frame_idx_str: [q53_col, ...]}}
    """
    gt_between = gt_gaz_df[gt_gaz_df['study_design'] == 'between']

    clip_to_q53_cols = defaultdict(list)
    for n, clip in q53_pos_to_clip.items():
        clip_to_q53_cols[clip].append(f'{n}_Q53')

    clip_to_group = {}
    for clip, q53_cols in clip_to_q53_cols.items():
        sorted_cols = sorted(q53_cols, key=lambda x: int(x.split('_')[0]))
        gt_frames   = sorted([int(f) for f in
                               gt_between[gt_between['clip_id'] == clip]['frame_idx'].tolist()])

        if len(gt_frames) == 1:
            clip_to_group[clip] = {str(gt_frames[0]): sorted_cols}
        elif len(gt_frames) == 2:
            half = len(sorted_cols) // 2
            clip_to_group[clip] = {
                str(gt_frames[0]): sorted_cols[:half],
                str(gt_frames[1]): sorted_cols[half:],
            }

    return clip_to_group, gt_between


# ═══════════════════════════════════════════════════════════════════════════
# LOAD DATA
# ═══════════════════════════════════════════════════════════════════════════

print("Loading data...")

gt_act = pd.read_excel(GT_PATH, sheet_name='Activity',   header=1)
gt_eng = pd.read_excel(GT_PATH, sheet_name='Engagement', header=1)
gt_gaz = pd.read_excel(GT_PATH, sheet_name='Gaze',       header=1)

gt_act['gt_set'] = gt_act['gt_answer'].apply(normalise_set)
act_lookup = {
    (str(r['study_design']).strip().lower(),
     str(r['clip_id']).strip(),
     str(r['question_type']).strip().lower()): r['gt_set']
    for _, r in gt_act.iterrows()
}
eng_lookup = {
    (str(r['study_design']).strip().lower(),
     str(r['clip_id']).strip()): normalise(str(r['gt_answer']))
    for _, r in gt_eng.iterrows()
}
gaz_lookup = {
    (str(r['study_design']).strip().lower(),
     str(r['clip_id']).strip(),
     str(int(r['frame_idx']))): normalise(str(r['gt_answer']))
    for _, r in gt_gaz.iterrows()
}

raw_file  = pd.read_csv(DATA_PATH, header=None)
col_names = list(raw_file.iloc[0])
qtexts    = list(raw_file.iloc[1])
data      = raw_file.iloc[3:].copy()
data.columns = col_names

# Participants excluded from analysis
EXCLUDED  = {"R_2PbOzedGEfSO1DR", "R_7q9H9RfaOnyjram"}  # P2: multi-selected activity_type (survey design issue)
data      = data[~data['ResponseId'].isin(EXCLUDED)].reset_index(drop=True)
data      = data.drop_duplicates('ResponseId', keep='first').reset_index(drop=True)

q17_map, q13_map, q33_map, q53_pos_to_clip, wa_map, we_map = \
    build_col_lookups(col_names, qtexts)

# Build fixed global (clip_id, frame_idx) -> Q53_col map using GT frame indices
q53_clip_groups, q53_gt_between = build_fixed_q53_map(q53_pos_to_clip, gt_gaz)

print(f"  GT activity entries     : {len(act_lookup)}")
print(f"  GT engagement entries   : {len(eng_lookup)}")
print(f"  GT gaze entries         : {len(gaz_lookup)}")
print(f"  Participant rows        : {len(data)}")
print(f"  Q17 clip->col entries   : {len(q17_map)}")
print(f"  Q13 clip->col entries   : {len(q13_map)}")
print(f"  Q33 clip->col entries   : {len(q33_map)}")
print(f"  Within-act lookup entries: {len(wa_map)}")
print(f"  Within-eng lookup entries: {len(we_map)}")


# ═══════════════════════════════════════════════════════════════════════════
# MODEL 1 — BETWEEN-SUBJECTS ACTIVITY
# clip_id  : Clip_n_ID
# modality : Clip_n_Modality
# Response : q17_map[clip_id] and q13_map[clip_id]
# ═══════════════════════════════════════════════════════════════════════════

print("\nModel 1: Between-subjects Activity...")
rows = []
for _, prow in data.iterrows():
    pid = prow.get('ResponseId', 'unknown')
    for n in range(1, 16):
        clip_id  = prow.get(f'Clip_{n}_ID')
        modality = prow.get(f'Clip_{n}_Modality')
        if pd.isna(clip_id):
            continue
        clip_id  = str(clip_id).strip()
        modality = str(modality).strip() if pd.notna(modality) else 'unknown'

        for lookup, q_type, max_sc in [
            (q17_map, 'activity_type',    4),
            (q13_map, 'actions_occurring', 8),
        ]:
            q_col  = lookup.get(clip_id)
            gt_set = act_lookup.get(('between', clip_id, q_type))
            if q_col is None or gt_set is None:
                continue
            response = prow.get(q_col)
            rows.append({
                'participant_id':   pid,
                'item_n':           n,
                'clip_id':          clip_id,
                'modality':         modality,
                'question_type':    q_type,
                'max_score':        max_sc,
                'participant_resp': str(response) if pd.notna(response) else None,
                'gt_answer':        ', '.join(sorted(gt_set)),
                **score_multiselect(response, gt_set),
            })

m1b = pd.DataFrame(rows)
m1b_irr = compute_irr_multiselect(m1b, ['question_type', 'modality'])
save_excel(m1b, m1b_irr, f'{OUT_DIR}/model1_between_activity.xlsx',
           ['participant_id','item_n','clip_id','modality','question_type',
            'max_score','participant_resp','gt_answer','score','exact_match',
            'precision','recall','f1','jaccard','n_correct','n_gt','n_response'])


# ═══════════════════════════════════════════════════════════════════════════
# MODEL 2 — BETWEEN-SUBJECTS ENGAGEMENT
# clip_id  : Engage_n_ID
# modality : Engage_n_Modality
# Response : q33_map[clip_id]
# ═══════════════════════════════════════════════════════════════════════════

print("\nModel 2: Between-subjects Engagement...")
rows = []
for _, prow in data.iterrows():
    pid = prow.get('ResponseId', 'unknown')
    for n in range(1, 16):
        clip_id  = prow.get(f'Engage_{n}_ID')
        modality = prow.get(f'Engage_{n}_Modality')
        if pd.isna(clip_id):
            continue
        clip_id  = str(clip_id).strip()
        modality = str(modality).strip() if pd.notna(modality) else 'unknown'

        q_col    = q33_map.get(clip_id)
        gt_label = eng_lookup.get(('between', clip_id))
        if q_col is None or gt_label is None:
            continue
        response = prow.get(q_col)
        s = score_single(response, gt_label, rank_map=ORDINAL_RANK)
        rows.append({
            'participant_id':   pid,
            'item_n':           n,
            'clip_id':          clip_id,
            'modality':         modality,
            'gt_answer':        gt_label,
            'participant_resp': normalise(str(response)) if pd.notna(response) else None,
            **s,
        })

m2b = pd.DataFrame(rows)
m2b['resp_rank'] = m2b['participant_resp'].map(ORDINAL_RANK)
m2b_irr = compute_irr_single(m2b, ['modality'], level='ordinal')
save_excel(m2b, m2b_irr, f'{OUT_DIR}/model2_between_engagement.xlsx',
           ['participant_id','item_n','clip_id','modality',
            'gt_answer','participant_resp','correct','ordinal_distance'])


# ═══════════════════════════════════════════════════════════════════════════
# MODEL 3 — BETWEEN-SUBJECTS GAZE
# clip_id   : Frame_n_ID
# frame_idx : Frame_n_Idx
# modality  : Frame_n_Modality
# Response  : find which Q53 col in clip's group has a response for this participant
# ═══════════════════════════════════════════════════════════════════════════

print("\nModel 3: Between-subjects Gaze...")
rows = []
for _, prow in data.iterrows():
    pid = prow.get('ResponseId', 'unknown')

    for n in range(1, 16):   # 15 frames
        clip_id   = prow.get(f'Frame_{n}_ID')
        frame_idx = prow.get(f'Frame_{n}_Idx')
        modality  = prow.get(f'Frame_{n}_Modality')
        if pd.isna(clip_id):
            continue
        clip_id   = str(clip_id).strip()
        frame_idx = str(int(frame_idx)) if pd.notna(frame_idx) else 'unknown'
        modality  = str(modality).strip().lower() if pd.notna(modality) else 'unknown'

        gt_label = gaz_lookup.get(('between', clip_id, frame_idx))
        if gt_label is None:
            print(f"  WARNING: no GT for clip={clip_id}, frame_idx={frame_idx}")
            continue

        # Find which Q53 col in this clip+frame_idx group has a response
        candidate_cols = q53_clip_groups.get(clip_id, {}).get(frame_idx, [])
        q53_col  = None
        response = None
        for cand in candidate_cols:
            val = prow.get(cand)
            if pd.notna(val) and str(val).strip() not in ['', 'nan']:
                q53_col  = cand
                response = val
                break

        if q53_col is None and not candidate_cols:
            print(f"  WARNING: no Q53 cols for clip={clip_id}, frame_idx={frame_idx}")
            continue

        s = score_single(response, gt_label)
        rows.append({
            'participant_id':   pid,
            'item_n':           n,
            'clip_id':          clip_id,
            'frame_idx':        frame_idx,
            'modality':         modality,
            'gt_answer':        gt_label,
            'participant_resp': normalise(str(response)) if pd.notna(response) else None,
            **s,
        })

m3b = pd.DataFrame(rows)
# For gaze IRR, use the actual response value (which ID was selected), not correct (0/1).
# This correctly measures agreement on WHAT participants said, not WHETHER they were right.
# Convert 'id 1','id 2' etc to numeric for Krippendorff computation.
m3b['resp_num'] = pd.to_numeric(
    m3b['participant_resp'].str.replace('id ', '').str.strip(), errors='coerce')
m3b_irr = compute_irr_single(m3b, ['modality'], level='nominal', val_col='resp_num')
save_excel(m3b, m3b_irr, f'{OUT_DIR}/model3_between_gaze.xlsx',
           ['participant_id','item_n','clip_id','frame_idx','modality',
            'gt_answer','participant_resp','correct'])


# ═══════════════════════════════════════════════════════════════════════════
# MODEL 4 — WITHIN-SUBJECTS ACTIVITY
# clip_id  : Within_Clip_n_ID
# Response : wa_map[(clip_id, q_type, modality)]
# ═══════════════════════════════════════════════════════════════════════════

print("\nModel 4: Within-subjects Activity...")
rows = []
for _, prow in data.iterrows():
    pid = prow.get('ResponseId', 'unknown')
    for n in range(1, 5):
        clip_id = prow.get(f'Within_Clip_{n}_ID')
        if pd.isna(clip_id):
            continue
        clip_id = str(clip_id).strip()

        for modality in ['anonymized_nosound', 'anonymized', 'blurred', 'raw']:
            for q_type, max_sc in [('activity_type', 4), ('actions_occurring', 8)]:
                q_col  = wa_map.get((clip_id, q_type, modality))
                gt_set = act_lookup.get(('within', clip_id, q_type))
                if q_col is None or gt_set is None:
                    continue
                response = prow.get(q_col)
                rows.append({
                    'participant_id':   pid,
                    'item_n':           n,
                    'clip_id':          clip_id,
                    'modality':         modality,
                    'question_type':    q_type,
                    'max_score':        max_sc,
                    'participant_resp': str(response) if pd.notna(response) else None,
                    'gt_answer':        ', '.join(sorted(gt_set)),
                    **score_multiselect(response, gt_set),
                })

m4w = pd.DataFrame(rows)
m4w_irr = compute_irr_multiselect(m4w, ['question_type', 'modality'])
save_excel(m4w, m4w_irr, f'{OUT_DIR}/model4_within_activity.xlsx',
           ['participant_id','item_n','clip_id','modality','question_type',
            'max_score','participant_resp','gt_answer','score','exact_match',
            'precision','recall','f1','jaccard','n_correct','n_gt','n_response'])


# ═══════════════════════════════════════════════════════════════════════════
# MODEL 5 — WITHIN-SUBJECTS ENGAGEMENT
# clip_id  : Within_Engage_n_ID
# Response : we_map[(clip_id, modality)]
# ═══════════════════════════════════════════════════════════════════════════

print("\nModel 5: Within-subjects Engagement...")
rows = []
for _, prow in data.iterrows():
    pid = prow.get('ResponseId', 'unknown')
    for n in range(1, 7):
        clip_id = prow.get(f'Within_Engage_{n}_ID')
        if pd.isna(clip_id):
            continue
        clip_id  = str(clip_id).strip()
        gt_label = eng_lookup.get(('within', clip_id))
        if gt_label is None:
            print(f"  WARNING: no GT for clip={clip_id} (within engagement)")
            continue

        for modality in ['anonymized_nosound', 'anonymized', 'blurred', 'raw']:
            q_col = we_map.get((clip_id, modality))
            if q_col is None:
                continue
            response = prow.get(q_col)
            s = score_single(response, gt_label, rank_map=ORDINAL_RANK)
            rows.append({
                'participant_id':   pid,
                'item_n':           n,
                'clip_id':          clip_id,
                'modality':         modality,
                'gt_answer':        gt_label,
                'participant_resp': normalise(str(response)) if pd.notna(response) else None,
                **s,
            })

m5w = pd.DataFrame(rows)
m5w['resp_rank'] = m5w['participant_resp'].map(ORDINAL_RANK)
m5w_irr = compute_irr_single(m5w, ['modality'], level='ordinal')
save_excel(m5w, m5w_irr, f'{OUT_DIR}/model5_within_engagement.xlsx',
           ['participant_id','item_n','clip_id','modality',
            'gt_answer','participant_resp','correct','ordinal_distance'])


# ═══════════════════════════════════════════════════════════════════════════
# MODEL 6 — WITHIN-SUBJECTS GAZE
# Within_Frame_n_ID correctly matches n_Q56 — no randomization issue.
# clip_id   : Within_Frame_n_ID
# frame_idx : Within_Frame_n_Idx
# modality  : Within_Frame_n_Modality
# Response  : n_Q56 (position n matches Within_Frame_n for all participants)
# ═══════════════════════════════════════════════════════════════════════════

print("\nModel 6: Within-subjects Gaze...")
rows = []
for _, prow in data.iterrows():
    pid = prow.get('ResponseId', 'unknown')
    for n in range(1, 13):
        clip_id   = prow.get(f'Within_Frame_{n}_ID')
        frame_idx = prow.get(f'Within_Frame_{n}_Idx')
        modality  = prow.get(f'Within_Frame_{n}_Modality')
        if pd.isna(clip_id):
            continue
        clip_id   = str(clip_id).strip()
        frame_idx = str(int(frame_idx)) if pd.notna(frame_idx) else 'unknown'
        modality  = str(modality).strip() if pd.notna(modality) else 'unknown'
        gt_label  = gaz_lookup.get(('within', clip_id, frame_idx))
        if gt_label is None:
            print(f"  WARNING: no GT for clip={clip_id}, frame_idx={frame_idx} (within gaze)")
            continue
        response = prow.get(f'{n}_Q56')
        s = score_single(response, gt_label)
        rows.append({
            'participant_id':   pid,
            'item_n':           n,
            'clip_id':          clip_id,
            'frame_idx':        frame_idx,
            'modality':         modality,
            'gt_answer':        gt_label,
            'participant_resp': normalise(str(response)) if pd.notna(response) else None,
            **s,
        })

m6w = pd.DataFrame(rows)
m6w['resp_num'] = pd.to_numeric(
    m6w['participant_resp'].str.replace('id ', '').str.strip(), errors='coerce')
m6w_irr = compute_irr_single(m6w, ['modality'], level='nominal', val_col='resp_num')
save_excel(m6w, m6w_irr, f'{OUT_DIR}/model6_within_gaze.xlsx',
           ['participant_id','item_n','clip_id','frame_idx','modality',
            'gt_answer','participant_resp','correct'])

print("\nAll 6 models complete.")
